package com.edu;
interface Shapes {
	   void draw();
	}
class Rectangle1 implements Shapes {

	   @Override
	   public void draw() {
	      System.out.println("Shapes: Rectangle");
	   }
	}
class Circle1 implements Shapes {

	   @Override
	   public void draw() {
	      System.out.println("Shapes: Circle");
	   }
	}
abstract class ShapeDecorator implements Shapes {
	   protected Shapes decoratedShape;

	   public ShapeDecorator(Shapes decoratedShape){
	      this.decoratedShape = decoratedShape;
	   }

	   public void draw(){
	      decoratedShape.draw();
	   }	
	}
class RedShapeDecorator extends ShapeDecorator {

	   public RedShapeDecorator(Shapes decoratedShape) {
	      super(decoratedShape);		
	   }

	   @Override
	   public void draw() {
	      decoratedShape.draw();	       
	      setRedBorder(decoratedShape);
	   }

	   private void setRedBorder(Shapes decoratedShape){
	      System.out.println("Border Color: Red");
	   }
	}

public class Decorator {

	public static void main(String[] args) {
		Shapes circle1 = new Circle1();

	      Shapes redCircle1 = new RedShapeDecorator(new Circle1());

	      Shapes redRectangle1 = new RedShapeDecorator(new Rectangle1());
	      System.out.println("Circle with normal border");
	      circle1.draw();

	      System.out.println("\nCircle of red border");
	      redCircle1.draw();

	      System.out.println("\nRectangle of red border");
	      redRectangle1.draw();
	}

}
